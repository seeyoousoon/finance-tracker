import 'package:flutter/material.dart';
import 'graph_screen.dart';
import 'add_transaction.dart';
import 'history_screen.dart';
import 'notifications_screen.dart';
import 'budget_screen.dart';
import 'ml_classifier.dart';
import '../models/transaction.dart' as model;
import '../services/ml_api_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<model.Transaction> transactions = [];
  String budgetSuggestion = '';
  Map<String, double> exceededBudgets = {};

  @override
  void initState() {
    super.initState();
    _loadTransactionsAndBudgets();
  }

  Future<void> _loadTransactionsAndBudgets() async {
    try {
      final txs = await MLApiService.fetchTransactions();
      setState(() => transactions = txs);

      final income = txs.where((t) => t.amount > 0).fold<double>(0.0, (s, t) => s + t.amount);
      final expense = txs.where((t) => t.amount < 0).fold<double>(0.0, (s, t) => s + t.amount.abs());

      final suggestion = await MLApiService.smartBudget(income, expense);
      setState(() => budgetSuggestion = suggestion);

      // Calculate exceeded budgets
      final categorySpending = <String, double>{};
      for (var t in txs) {
        if (t.amount < 0) {
          categorySpending[t.category] = (categorySpending[t.category] ?? 0) + t.amount.abs();
        }
      }

      final classifier = MLClassifier();
      await classifier.loadModel();

      final budgetLimits = await classifier.suggestBudget({
        for (var entry in categorySpending.entries) entry.key: [entry.value]
      });

      final exceeded = <String, double>{};
      for (var entry in categorySpending.entries) {
        final budget = budgetLimits[entry.key] ?? double.infinity;
        if (entry.value > budget) {
          exceeded[entry.key] = entry.value - budget;
        }
      }
      exceeded['Food'] = 135.0;
      print("📢 Exceeded Budgets = $exceeded");

      setState(() => exceededBudgets = exceeded);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error loading transactions: $e")),
      );
    }
  }

  Widget _summaryTile(String title, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
          Text(value,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }

  Widget _dashboardButton(String text, Color color, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
      ),
      child: Text(text),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalIncome = transactions
        .where((t) => t.amount > 0)
        .fold<double>(0.0, (s, t) => s + t.amount);

    final totalExpenses = transactions
        .where((t) => t.amount < 0)
        .fold<double>(0.0, (s, t) => s + t.amount.abs());

    final balance = totalIncome - totalExpenses;

    return Scaffold(
      appBar: AppBar(title: const Text("Finance Dashboard")),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(16),
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: IntrinsicHeight(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Financial Summary",
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey[200],
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          _summaryTile("Income", "\$${totalIncome.toStringAsFixed(2)}", Colors.green),
                          _summaryTile("Expenses", "\$${totalExpenses.toStringAsFixed(2)}", Colors.red),
                          _summaryTile("Balance", "\$${balance.toStringAsFixed(2)}", Colors.blue),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _dashboardButton("Add Expense", Colors.purple, () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const AddTransactionScreen()),
                          ).then((_) => _loadTransactionsAndBudgets());
                        }),
                        _dashboardButton("View Graph", Colors.blue, () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const GraphScreen()),
                          );
                        }),
                        _dashboardButton("View History", Colors.orange, () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const HistoryScreen()),
                          );
                        }),
                        _dashboardButton("View Budget", Colors.teal, () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const BudgetScreen()),
                          );
                        }),
                        _dashboardButton("View Notifications", Colors.red, () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => NotificationsScreen(
                                anomalies: transactions.where((t) => t.anomaly).toList(),
                                exceededBudgets: exceededBudgets,
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}