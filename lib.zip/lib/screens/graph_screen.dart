import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../services/ml_api_service.dart';
import '../models/transaction.dart' as model;

class GraphScreen extends StatefulWidget {
  const GraphScreen({Key? key}) : super(key: key);

  @override
  _GraphScreenState createState() => _GraphScreenState();
}

class _GraphScreenState extends State<GraphScreen> {
  List<model.Transaction> transactions = [];

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  Future<void> _loadTransactions() async {
    try {
      final txs = await MLApiService.fetchTransactions();
      setState(() {
        transactions = txs;
      });
    } catch (e) {
      print("Error fetching transactions: $e");
    }
  }

  /// Build Pie Chart Sections for spending category distribution.
  List<PieChartSectionData> _buildPieChartSections() {
    // Group negative transactions (expenses) by category and sum their absolute amounts.
    Map<String, double> categoryTotals = {};
    for (var tx in transactions) {
      if (tx.amount < 0) {
        categoryTotals[tx.category] = (categoryTotals[tx.category] ?? 0) + tx.amount.abs();
      }
    }
    // If no expense data exists, fallback to dummy data for demonstration.
    if (categoryTotals.isEmpty) {
      categoryTotals = {
        "Food": 30,
        "Rent": 25,
        "Entertainment": 15,
        "Transport": 10,
        "Others": 20,
      };
    }

    List<PieChartSectionData> sections = [];
    List<Color> colors = [
      Colors.blue,
      Colors.red,
      Colors.orange,
      Colors.green,
      Colors.purple,
    ];
    int index = 0;
    categoryTotals.forEach((category, total) {
      sections.add(
        PieChartSectionData(
          color: colors[index % colors.length],
          value: total,
          title: '$category\n\$${total.toStringAsFixed(0)}',
          radius: 60,
          titleStyle: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      );
      index++;
    });

    return sections;
  }

  /// Build a Line Chart to display expense forecast data.
  /// Currently using dummy forecast data for 7 periods.
  Widget _buildLineChart() {
    // Dummy forecast data: Each FlSpot represents a time point (e.g., period) and a forecasted expense value.
    final List<FlSpot> forecastSpots = [
      const FlSpot(0, 65),
      const FlSpot(1, 70),
      const FlSpot(2, 68),
      const FlSpot(3, 72),
      const FlSpot(4, 75),
      const FlSpot(5, 71),
      const FlSpot(6, 73),
    ];

    return LineChart(
      LineChartData(
        minX: 0,
        maxX: 6,
        minY: 60,
        maxY: 80,
        gridData: FlGridData(show: true),
        borderData: FlBorderData(
          show: true,
          border: Border.all(color: Colors.grey),
        ),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              getTitlesWidget: (value, meta) {
                // Label time periods as P1, P2, etc.
                return Text('P${value.toInt() + 1}', style: const TextStyle(fontSize: 12));
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                return Text('\$${value.toInt()}', style: const TextStyle(fontSize: 12));
              },
            ),
          ),
        ),
        lineBarsData: [
          LineChartBarData(
            spots: forecastSpots,
            isCurved: true,
            barWidth: 3,
            dotData: FlDotData(show: true),
            color: Colors.blue,
            belowBarData: BarAreaData(
              show: true,
              color: Colors.blue.withOpacity(0.3),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Expense Analytics")),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Pie Chart Section for Spending Distribution
              const Text(
                "Spending Category Distribution",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 300,
                child: PieChart(
                  PieChartData(
                    sections: _buildPieChartSections(),
                    sectionsSpace: 2,
                    centerSpaceRadius: 40,
                    borderData: FlBorderData(show: false),
                  ),
                ),
              ),
              const SizedBox(height: 32),
              // Line Chart Section for Expense Forecast
              const Text(
                "Expense Forecast",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 300,
                child: _buildLineChart(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}