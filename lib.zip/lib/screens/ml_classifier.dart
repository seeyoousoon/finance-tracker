import 'dart:math';
import 'package:flutter/services.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

class MLClassifier {
  Interpreter? _interpreter;
  List<String>? _labels;

  /// Loads the TFLite model and labels from the assets folder.
  Future<void> loadModel() async {
    try {
      // Load the TFLite model from assets/model.tflite
      _interpreter = await Interpreter.fromAsset('assets/model.tflite');

      // Load the labels from assets/labels.txt
      String labelsData = await rootBundle.loadString('assets/labels.txt');
      _labels = labelsData
          .split('\n')
          .map((label) => label.trim())
          .where((label) => label.isNotEmpty)
          .toList();
      print("Model and labels loaded successfully.");
    } catch (e) {
      print("Error loading model: $e");
    }
  }

  /// Expense Auto-Tagging: Uses the loaded TFLite model to predict a category for the input text.
  Future<String> classify(String inputText) async {
    // Ensure model is loaded.
    if (_interpreter == null) {
      await loadModel();
    }

    // Preprocess the input text into a fixed-length vector.
    List<double> inputVector = _preprocess(inputText);
    // Reshape input to match the model's expected shape, e.g., [1, fixedSize].
    var input = [inputVector];

    // Assume model outputs a probability vector of size equal to the number of labels.
    int outputSize = _labels?.length ?? 5;
    var output = [List.filled(outputSize, 0.0)];

    // Run inference.
    _interpreter!.run(input, output);

    // Find the index with the highest predicted probability.
    int index = _argMax(output[0]);
    return _labels?[index] ?? "Unknown";
  }

  /// Dummy preprocessing: Converts input text to a fixed-size vector (50 elements)
  /// by normalizing the character codes. Adapt this to match your model input.
  List<double> _preprocess(String text) {
    int fixedSize = 50;
    List<double> vector = List.filled(fixedSize, 0.0);
    List<int> codeUnits = text.codeUnits;
    for (int i = 0; i < min(fixedSize, codeUnits.length); i++) {
      vector[i] = codeUnits[i] / 255.0;
    }
    return vector;
  }

  /// Returns the index of the maximum value from a list of doubles.
  int _argMax(List<double> list) {
    int index = 0;
    double maxVal = list[0];
    for (int i = 1; i < list.length; i++) {
      if (list[i] > maxVal) {
        maxVal = list[i];
        index = i;
      }
    }
    return index;
  }

  /// Expense Forecasting: Returns a dummy forecast value based on the average of past expenses.
  Future<double> forecastExpense(List<double> pastExpenses) async {
    if (pastExpenses.isEmpty) return 0.0;
    double average = pastExpenses.reduce((a, b) => a + b) / pastExpenses.length;
    // Add a random fluctuation of ±10%
    double fluctuation = average * (Random().nextDouble() * 0.2 - 0.1);
    return average + fluctuation;
  }

  /// Smart Budget Suggestion: Recommends a budget for each category based on past spending.
  /// [categorySpending] is a map with category names as keys and lists of expense amounts as values.
  Future<Map<String, double>> suggestBudget(Map<String, List<double>> categorySpending) async {
    Map<String, double> suggestions = {};
    categorySpending.forEach((category, expenses) {
      if (expenses.isNotEmpty) {
        double avg = expenses.reduce((a, b) => a + b) / expenses.length;
        suggestions[category] = avg * 1.2;
      } else {
        suggestions[category] = 0.0;
      }
    });
    return suggestions;
  }
}