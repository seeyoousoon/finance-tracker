import 'package:flutter/material.dart';
import '../services/ml_api_service.dart';

class TestIntegrationScreen extends StatefulWidget {
  const TestIntegrationScreen({Key? key}) : super(key: key);

  @override
  _TestIntegrationScreenState createState() => _TestIntegrationScreenState();
}

class _TestIntegrationScreenState extends State<TestIntegrationScreen> {
  String anomalyResult = '';
  String budgetSuggestion = '';
  final TextEditingController anomalyController = TextEditingController();
  final TextEditingController incomeController = TextEditingController();
  final TextEditingController expenditureController = TextEditingController();

  Future<void> testAnomaly() async {
    try {
      double amount = double.parse(anomalyController.text);
      bool isAnomaly = await MLApiService.detectAnomaly(amount);
      setState(() {
        anomalyResult = isAnomaly ? 'Anomaly Detected' : 'No Anomaly';
      });
    } catch (e) {
      setState(() {
        anomalyResult = 'Error: $e';
      });
    }
  }

  Future<void> testBudget() async {
    try {
      double income = double.parse(incomeController.text);
      double expenditure = double.parse(expenditureController.text);
      String suggestion = await MLApiService.smartBudget(income, expenditure);
      setState(() {
        budgetSuggestion = suggestion;
      });
    } catch (e) {
      setState(() {
        budgetSuggestion = 'Error: $e';
      });
    }
  }

  @override
  void dispose() {
    anomalyController.dispose();
    incomeController.dispose();
    expenditureController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Backend Integration Test'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Anomaly Detection', style: TextStyle(fontSize: 20)),
            TextField(
              controller: anomalyController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Enter transaction amount',
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: testAnomaly,
              child: const Text('Test Anomaly Detection'),
            ),
            const SizedBox(height: 8),
            Text('Result: $anomalyResult'),
            const Divider(height: 32),
            const Text('Smart Budget Suggestion', style: TextStyle(fontSize: 20)),
            TextField(
              controller: incomeController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Enter income',
              ),
            ),
            TextField(
              controller: expenditureController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Enter expenditure',
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: testBudget,
              child: const Text('Test Smart Budget'),
            ),
            const SizedBox(height: 8),
            Text('Suggestion: $budgetSuggestion'),
          ],
        ),
      ),
    );
  }
}