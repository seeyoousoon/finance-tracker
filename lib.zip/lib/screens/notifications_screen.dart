import 'package:flutter/material.dart';
import '../models/transaction.dart';

class NotificationsScreen extends StatelessWidget {
  final List<Transaction> anomalies;
  final Map<String, double> exceededBudgets;

  const NotificationsScreen({
    Key? key,
    required this.anomalies,
    required this.exceededBudgets,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final defaultNotifications = [
      {
        "title": "Monthly Summary",
        "message": "Your income this month: \$5000, Expenses: \$3000.",
        "read": false,
      },
      {
        "title": "Financial Tip",
        "message": "Save 20% of your income for emergencies.",
        "read": false,
      },
    ];

    // Debug print for visibility
    print("🟠 anomalies received: ${anomalies.length}");
    print("🟧 exceededBudgets received: $exceededBudgets");

    return Scaffold(
      appBar: AppBar(title: const Text("Notifications")),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (anomalies.isNotEmpty) ...[
            const Text(
              "⚠ Anomalous Transactions",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red),
            ),
            const SizedBox(height: 10),
            ...anomalies.map((t) => Card(
              color: Colors.red[50],
              child: ListTile(
                leading: const Icon(Icons.warning, color: Colors.red),
                title: Text(t.title),
                subtitle: Text("Category: ${t.category}"),
                trailing: Text(
                  "\$${t.amount.toStringAsFixed(2)}",
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.red,
                  ),
                ),
              ),
            )),
            const Divider(height: 30),
          ],
          if (exceededBudgets.isNotEmpty) ...[
            const Text(
              "⚠ Budget Warnings",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.orange),
            ),
            const SizedBox(height: 10),
            ...exceededBudgets.entries.map((entry) => Card(
              color: Colors.orange[50],
              child: ListTile(
                leading: const Icon(Icons.warning_amber, color: Colors.orange),
                title: Text("Budget Exceeded: ${entry.key}"),
                subtitle: Text(
                  "You went over your ${entry.key} budget by \$${entry.value.toStringAsFixed(2)}",
                ),
              ),
            )),
            const Divider(height: 30),
          ] else ...[
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text(
                "No exceeded budgets. Well done! 🎉",
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
          const Text(
            "General Notifications",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ...defaultNotifications.map((n) {
            final title = n['title'] as String? ?? '';
            final message = n['message'] as String? ?? '';
            return Card(
              child: ListTile(
                leading: const Icon(Icons.notifications),
                title: Text(title),
                subtitle: Text(message),
              ),
            );
          }),
        ],
      ),
    );
  }
}