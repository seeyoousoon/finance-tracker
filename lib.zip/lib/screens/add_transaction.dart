import 'package:flutter/material.dart';
import '../services/ml_api_service.dart';
import '../models/transaction.dart' as model;

class AddTransactionScreen extends StatefulWidget {
  const AddTransactionScreen({Key? key}) : super(key: key);

  @override
  _AddTransactionScreenState createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController amountController = TextEditingController();

  String autoTagResult = '';
  bool isSaving = false;
  bool? isAnomaly;

  List<model.Transaction> transactions = [];

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  Future<void> _loadTransactions() async {
    try {
      final txs = await MLApiService.fetchTransactions();
      setState(() {
        transactions = txs;
      });
    } catch (e) {
      print("Error fetching transactions: $e");
    }
  }

  Future<void> autoTag() async {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      setState(() => autoTagResult = '');
      return;
    }
    try {
      final rawCategory = await MLApiService.getAutoTag(title);
      final normalized = _normalizeCategory(rawCategory);
      setState(() => autoTagResult = normalized);
    } catch (e) {
      print("AutoTag error: $e");
      setState(() => autoTagResult = 'Misc');
    }
  }

  String _normalizeCategory(String raw) {
    final cleaned = raw.trim().toLowerCase();
    if (cleaned.contains("food") || cleaned.contains("drink")) return "Food";
    if (cleaned.contains("utilit")) return "Utilities";
    if (cleaned.contains("rent")) return "Rent";
    if (cleaned.contains("clothing") ||
        cleaned.contains("apparel") ||
        cleaned.contains("fashion"))
      return "Clothing";
    return "Misc";
  }

  Future<void> saveTransaction() async {
    final title = titleController.text.trim();
    final amtText = amountController.text.trim();
    if (title.isEmpty || amtText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter both title and amount')),
      );
      return;
    }
    final amt = double.tryParse(amtText);
    if (amt == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid amount')),
      );
      return;
    }

    setState(() {
      isSaving = true;
      isAnomaly = null;
    });

    try {
      final category = autoTagResult.isNotEmpty ? autoTagResult : 'Misc';
      final anomalyFlag = await MLApiService.detectAnomaly(amt);
      setState(() {
        isAnomaly = anomalyFlag;
      });

      final success = await MLApiService.saveTransaction(title, amt, category);
      if (success) {
        titleController.clear();
        amountController.clear();
        setState(() {
          autoTagResult = '';
          isAnomaly = null;
        });
        await _loadTransactions();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to save transaction')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() {
        isSaving = false;
      });
    }
  }

  void clearTransactions() {
    setState(() {
      transactions.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('All transactions cleared')),
    );
  }

  @override
  void dispose() {
    titleController.dispose();
    amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add & View Transactions")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'Title'),
              onChanged: (_) => autoTag(),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: amountController,
              decoration: const InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('Auto-tag: ', style: TextStyle(fontWeight: FontWeight.w500)),
                Text(autoTagResult.isEmpty ? '—' : autoTagResult),
              ],
            ),
            if (isAnomaly != null)
              Row(
                children: [
                  const Text('Anomaly: ', style: TextStyle(fontWeight: FontWeight.w500)),
                  Text(
                    isAnomaly! ? '⚠ Unusual transaction detected' : '✓ Looks normal',
                    style: TextStyle(
                      color: isAnomaly! ? Colors.red : Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: isSaving ? null : saveTransaction,
              child: isSaving
                  ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
                  : const Text('Save Transaction'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: clearTransactions,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Clear All Transactions'),
            ),
            const Divider(height: 32),
            Expanded(
              child: transactions.isEmpty
                  ? const Center(child: Text('No transactions yet'))
                  : ListView.builder(
                itemCount: transactions.length,
                itemBuilder: (ctx, i) {
                  final t = transactions[i];
                  return ListTile(
                    title: Text(t.title),
                    subtitle: Text(t.category),
                    trailing: Text(
                      '\$${t.amount.toStringAsFixed(2)}',
                      style: TextStyle(
                        color: t.amount >= 0 ? Colors.green : Colors.red,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}