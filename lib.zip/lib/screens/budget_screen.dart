import 'package:flutter/material.dart';
import 'ml_classifier.dart'; // Import the MLClassifier
import '../models/transaction.dart' as model;
import '../services/ml_api_service.dart'; // For fetching transactions

class BudgetScreen extends StatefulWidget {
  const BudgetScreen({Key? key}) : super(key: key);

  @override
  _BudgetScreenState createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  List<model.Transaction> transactions = [];
  bool isLoading = true;

  // This map holds the ML suggested budgets per category (category -> suggested budget).
  Map<String, double> suggestedBudgets = {};

  // We'll create an instance of your MLClassifier to load the model and call suggestBudget().
  final MLClassifier _classifier = MLClassifier();

  @override
  void initState() {
    super.initState();
    _loadTransactionsAndBudgetSuggestions();
  }

  /// Fetch transactions and then get ML-based budget suggestions.
  Future<void> _loadTransactionsAndBudgetSuggestions() async {
    setState(() {
      isLoading = true;
    });
    try {
      // 1. Fetch transactions from your backend.
      final txs = await MLApiService.fetchTransactions();
      setState(() => transactions = txs);

      // 2. Group expenses by category for your classifier.
      final Map<String, List<double>> categorySpending = {};
      for (var t in txs) {
        if (t.amount < 0) {
          final absVal = t.amount.abs();
          categorySpending.putIfAbsent(t.category, () => []).add(absVal);
        }
      }

      // 3. Load the TFLite model if not already loaded.
      await _classifier.loadModel();

      // 4. Use classifier's suggestBudget method to get recommended budgets for each category.
      final suggestions = await _classifier.suggestBudget(categorySpending);

      setState(() {
        suggestedBudgets = suggestions;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error loading data: $e")),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  /// Calculates how much a user has spent for a given category from the fetched transactions.
  double _calculateSpending(String category) {
    return transactions
        .where((t) => t.amount < 0 && t.category == category)
        .fold<double>(0.0, (sum, t) => sum + t.amount.abs());
  }

  /// Builds a card showing how much user spent vs. ML-suggested budget for each category.
  Widget _buildBudgetCard(String category, double suggestedBudget) {
    final spent = _calculateSpending(category);
    final pct = spent / (suggestedBudget > 0 ? suggestedBudget : 1);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      elevation: 3,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(category,
                style:
                const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: pct > 1 ? 1 : pct,
              backgroundColor: Colors.grey[300],
              color: pct >= 1 ? Colors.red : Colors.green,
            ),
            const SizedBox(height: 8),
            Text(
              "Spent: \$${spent.toStringAsFixed(2)} / Budget: \$${suggestedBudget.toStringAsFixed(2)}",
              style: const TextStyle(fontSize: 16),
            ),
            if (spent > suggestedBudget)
              const Padding(
                padding: EdgeInsets.only(top: 8.0),
                child: Text(
                  "⚠ Budget Exceeded!",
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Create a sorted list of categories from the suggestedBudgets map.
    final categories = suggestedBudgets.keys.toList()..sort();

    return Scaffold(
      appBar: AppBar(title: const Text("ML Budget Tracker")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "ML-based Budget Suggestions",
              style:
              TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: categories.isEmpty
                  ? const Center(child: Text("No categories found"))
                  : ListView.builder(
                itemCount: categories.length,
                itemBuilder: (ctx, index) {
                  final category = categories[index];
                  final limit = suggestedBudgets[category] ?? 0.0;
                  return _buildBudgetCard(category, limit);
                },
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: ElevatedButton(
                onPressed: _loadTransactionsAndBudgetSuggestions,
                child: const Text("Refresh ML Budget"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}