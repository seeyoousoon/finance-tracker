import 'package:flutter/material.dart';
import 'home_screen.dart'; // Importing our home screen widget

class LoginScreen extends StatefulWidget { // Defining LoginScreen widget user's input
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> { // state for  LoginScreen for interaction logic

  final _formKey = GlobalKey<FormState>();  // A unique key for validation.

  final TextEditingController _emailController = TextEditingController(); // Controllers to retrieve email
  final TextEditingController _passwordController = TextEditingController(); // Controllers to retrieve password

  String? _errorMessage;  // A variable to hold error

  void _login() { // for login button.
    if (_formKey.currentState!.validate()) { // fields are not empty or not

      setState(() {
        _errorMessage = null;
      });

      if (_emailController.text == "tanusha.basnet@gmail.com" && // credentails for for login
          _passwordController.text == "123456789"
              "") {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );
      } else {
        // If the credentials are wrong, display an error message.
        setState(() {
          _errorMessage = "Invalid email or password";
        });
      }
    }
  }

  // The build method creates the visual layout of the login screen.
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(title: Text("Login")),

      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Center(

          child: SingleChildScrollView( //to scroll
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Finance Tracker",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 20),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // The email text field with an email icon and a label.
                      TextFormField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          labelText: "Email",
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.email),
                        ),
                        keyboardType: TextInputType.emailAddress,
                        // To check that the email field is not empty.
                        validator: (value) => value!.isEmpty ? "Enter your email" : null,
                      ),
                      SizedBox(height: 10),
                      // The password text field which hides the input for privacy.
                      TextFormField(
                        controller: _passwordController,
                        decoration: InputDecoration(
                          labelText: "Password",
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.lock),
                        ),
                        obscureText: true,
                        // Check that the password field is not empty.
                        validator: (value) => value!.isEmpty ? "Enter your password" : null,
                      ),
                      SizedBox(height: 10),
                      // If there's an error message (like wrong login info), show it in red text.
                      if (_errorMessage != null)
                        Text(_errorMessage!, style: TextStyle(color: Colors.red)),
                      SizedBox(height: 20),
                      // The login button that triggers the _login function when pressed.
                      ElevatedButton(
                        onPressed: _login,
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size(double.infinity, 50),
                          textStyle: TextStyle(fontSize: 16),
                        ),
                        child: Text("Login"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
