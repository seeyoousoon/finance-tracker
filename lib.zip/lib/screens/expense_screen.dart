import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'ml_classifier.dart';

class ExpenseScreen extends StatefulWidget {
  const ExpenseScreen({Key? key}) : super(key: key);

  @override
  _ExpenseScreenState createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends State<ExpenseScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  String _predictedCategory = "Unknown";
  final MLClassifier _classifier = MLClassifier();

  @override
  void initState() {
    super.initState();
    // Load your ML model (dummy or TFLite)
    _classifier.loadModel();
  }

  /// Auto-Tag the expense by calling the ML classifier
  Future<void> _classifyExpense() async {
    final title = _titleController.text.trim();
    if (title.isNotEmpty) {
      final category = await _classifier.classify(title);
      setState(() {
        _predictedCategory = category;
      });
    }
  }

  /// Save the expense data to Firestore
  Future<void> _saveExpense() async {
    final amount = double.tryParse(_amountController.text.trim());
    if (_titleController.text.isEmpty || amount == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a valid description and amount.")),
      );
      return;
    }

    await FirebaseFirestore.instance.collection('expenses').add({
      'title': _titleController.text.trim(),
      'amount': amount,
      'predictedCategory': _predictedCategory,
      'date': DateTime.now(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Expense saved successfully.")),
    );
    Navigator.pop(context); // Return to the previous screen
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Expense")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Field for the expense description
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: "Expense Description"),
            ),
            // Field for the expense amount
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(labelText: "Amount"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            // Button to auto-tag category using ML
            ElevatedButton(
              onPressed: _classifyExpense,
              child: const Text("Auto-Tag Category"),
            ),
            const SizedBox(height: 8),
            Text("Predicted Category: $_predictedCategory"),
            const SizedBox(height: 20),
            // Button to save the expense
            ElevatedButton(
              onPressed: _saveExpense,
              child: const Text("Save Expense"),
            ),
          ],
        ),
      ),
    );
  }
}