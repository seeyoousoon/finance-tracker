class Transaction {
  final String title;
  final double amount;
  final String category;
  final bool anomaly;

  Transaction({
    required this.title,
    required this.amount,
    required this.category,
    this.anomaly = false,
  });

  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      title: json['title'] as String,
      amount: (json['amount'] as num).toDouble(),
      category: json['category'] as String,
      anomaly: json['anomaly'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'amount': amount,
      'category': category,
      'anomaly': anomaly,
    };
  }
}