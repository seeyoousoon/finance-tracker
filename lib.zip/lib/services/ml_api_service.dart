import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import '../models/transaction.dart' as model;

/// Model for expense forecasting data.
class ForecastData {
  final DateTime date;
  final double expense;

  ForecastData({
    required this.date,
    required this.expense,
  });

  factory ForecastData.fromJson(Map<String, dynamic> json) {
    return ForecastData(
      date: DateTime.parse(json['date']),
      expense: (json['expense'] as num).toDouble(),
    );
  }
}

/// Service class for interacting with the ML backend.
class MLApiService {
  // For Android emulator, use 10.0.2.2; adjust if running on a physical device.
  static const String baseUrl = 'http://10.0.2.2:5000';

  /// Returns the auto-tagged category for a given transaction title.
  static Future<String> getAutoTag(String title) async {
    final url = Uri.parse('$baseUrl/auto-tag');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'title': title}),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['category'] as String;
    } else {
      throw Exception('Failed to get auto-tag');
    }
  }

  /// Checks if the provided amount is anomalous.
  static Future<bool> detectAnomaly(double amount) async {
    final url = Uri.parse('$baseUrl/detect-anomaly');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'amount': amount}),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['anomaly'] as bool;
    } else {
      throw Exception('Failed to detect anomaly');
    }
  }

  /// Suggests a smart budget based on given income and expenditure.
  static Future<String> smartBudget(double income, double expenditure) async {
    final url = Uri.parse('$baseUrl/smart-budget');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'income': income,
        'expenditure': expenditure,
      }),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['suggestion'] as String;
    } else {
      throw Exception('Failed to get smart budget suggestion');
    }
  }

  /// Saves a new transaction with the provided title, amount, and category.
  static Future<bool> saveTransaction(String title, double amount, String category) async {
    final url = Uri.parse('$baseUrl/save-transaction');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'title': title,
        'amount': amount,
        'category': category,
      }),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['success'] as bool;
    } else {
      throw Exception('Failed to save transaction');
    }
  }

  /// Fetches all saved transactions from the backend.
  static Future<List<model.Transaction>> fetchTransactions() async {
    final url = Uri.parse('$baseUrl/transactions');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final List<dynamic> list = jsonDecode(response.body);
      return list.map((e) => model.Transaction.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load transactions');
    }
  }

  /// Retrieves expense forecast data from the backend.
  static Future<List<ForecastData>> getExpenseForecast() async {
    final url = Uri.parse('$baseUrl/expense-forecast');
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final List<dynamic> list = jsonDecode(response.body);
      return list.map((e) => ForecastData.fromJson(e)).toList();
    } else {
      throw Exception('Failed to get expense forecast');
    }
  }

  /// Dummy Implementation: Forecasts the next expense based on past expenses.
  static Future<double> forecastExpense(List<double> pastExpenses) async {
    if (pastExpenses.isEmpty) return 0.0;
    double avg = pastExpenses.reduce((a, b) => a + b) / pastExpenses.length;
    double fluctuation = avg * (Random().nextDouble() * 0.2 - 0.1); // ±10%
    return avg + fluctuation;
  }

  /// Clears all transactions from backend storage (for testing/reset).
  static Future<void> clearAllTransactions() async {
    final url = Uri.parse('$baseUrl/clear-transactions');
    final response = await http.delete(url);
    if (response.statusCode != 200) {
      throw Exception('Failed to clear transactions');
    }
  }
}