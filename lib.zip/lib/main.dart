import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/add_transaction.dart';
import 'screens/test_integration_screen.dart';
import 'screens/graph_screen.dart';

void main() {
  runApp(FinanceTrackerApp());
}

class FinanceTrackerApp extends StatelessWidget {
  // Removed 'const' here
  FinanceTrackerApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Finance Tracker',
      debugShowCheckedModeBanner: false,
      // Removed 'const' from named constructors in routes:
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginScreen(),
        '/home': (context) => HomeScreen(),
        '/graph': (context) => GraphScreen(),
        '/add-transaction': (context) => AddTransactionScreen(),
        '/test-integration': (context) => TestIntegrationScreen()
      },
    );
  }
}