
class InterpreterOptions {
  void setNumThreads(int threads) {
    // No-op for mock
  }
}
